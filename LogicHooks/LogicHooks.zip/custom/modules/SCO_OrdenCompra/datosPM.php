<?php
/**
*esta clase extrae todo los datos para la integracion con el proceso de Solicitud de adquisiciones MHES
*@author Yilmar Choque <jose.choque.m@hansa.com.bo>
*@copyright 2020
*@license /var/www/html/custom/modules/SCO_Aprobadores
*/

class Cldatospm
{   static $already_ran = false;
    function datosapr($bean, $event, $arguments) {
        
     echo "hola mundo";   
    }
}

?>