<?php
echo "hola mundo";
?>