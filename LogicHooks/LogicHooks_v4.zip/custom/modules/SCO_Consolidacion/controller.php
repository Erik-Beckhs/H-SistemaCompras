<?php 
/**
*Esta clase realiza la accion de vista de creacion de consolidacion.
*
*@author Limberg Alcon <lalcon@hansa.com.bo>
*@copyright 2020
*@license /var/www/html/custom/modules/SCO_Consolidacion
*/
class SCO_ConsolidacionController extends SugarController {  

  function action_creacion() {
    $this-> view = 'creacion';
  }
  
}
?>
