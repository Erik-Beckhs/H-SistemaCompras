<?php 
/*
class Clnomdist
{
	function Fnnomdist($bean, $event, $arguments) 
 	{
 		$bean->name = $bean->dis_contacto;
 		$bean->save();
	}
}
*/
?>