<?php
/**
*Esta clase es una modificacion a la vista de edicion del modulo de SCO_ORDENCOMPRA.
*
*@author Limberg Alcon <lalcon@hansa.com.bo>
*@copyright 2018
*@license /var/www/html/custom/modules/SCO_OrdenCompra
*/
class Clviewoc
{
  function Fnviewoc()
  {
    switch ($GLOBALS['app']->controller->action)
    {
      case "EditView":
      
      break;
    }
  }
}
?>
