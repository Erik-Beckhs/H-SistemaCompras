<?php
$module_name = 'SCO_Consolidacion';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'CON_DESCRIPCION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CON_DESCRIPCION',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'CON_ESTADO' => 
  array (
    'type' => 'dynamicenum',
    'studio' => 'visible',
    'label' => 'LBL_CON_ESTADO',
    'width' => '10%',
    'default' => true,
  ),
  'CON_CANTITEMS' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CON_CANTITEMS',
    'width' => '10%',
    'default' => true,
  ),
  'SCO_CONSOLIDACION_SCO_ORDENCOMPRA_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_SCO_CONSOLIDACION_SCO_ORDENCOMPRA_FROM_SCO_ORDENCOMPRA_TITLE',
    'id' => 'SCO_CONSOLIDACION_SCO_ORDENCOMPRASCO_ORDENCOMPRA_IDB',
    'width' => '10%',
    'default' => true,
  ),
  'SCO_CONSOLIDACION_SCO_PROVEEDOR_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_SCO_CONSOLIDACION_SCO_PROVEEDOR_FROM_SCO_PROVEEDOR_TITLE',
    'id' => 'SCO_CONSOLIDACION_SCO_PROVEEDORSCO_PROVEEDOR_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
;
?>
