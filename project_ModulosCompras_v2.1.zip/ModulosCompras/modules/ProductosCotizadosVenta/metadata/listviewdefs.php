<?php
$module_name = 'SCO_ProductosCotizadosVenta';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PCV_NOMBREPROVEEDOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_NOMBREPROVEEDOR',
    'width' => '10%',
    'default' => true,
  ),
  'SCO_PRODUCTOSCOTIZADOSVENTA_SCO_PROVEEDOR_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_SCO_PRODUCTOSCOTIZADOSVENTA_SCO_PROVEEDOR_FROM_SCO_PROVEEDOR_TITLE',
    'id' => 'SCO_PRODUCTOSCOTIZADOSVENTA_SCO_PROVEEDORSCO_PROVEEDOR_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_PROVEEDORAIO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_PROVEEDORAIO',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_DESCRIPCION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_DESCRIPCION',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_AM' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_PCV_AM',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_FAMILIA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_FAMILIA',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_VENDEDOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_VENDEDOR',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_CLIENTE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_CLIENTE',
    'width' => '10%',
    'default' => true,
  ),
  'SCO_CONSOLIDACION_SCO_PRODUCTOSCOTIZADOSVENTA_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_SCO_CONSOLIDACION_SCO_PRODUCTOSCOTIZADOSVENTA_FROM_SCO_CONSOLIDACION_TITLE',
    'id' => 'SCO_CONSOLF10BIDACION_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_NUMEROCOTIZACION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_NUMEROCOTIZACION',
    'width' => '10%',
    'default' => false,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
;
?>
