<?php
$module_name = 'SCO_Cnf_Eventos_list';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'tipo' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_TIPO',
        'width' => '10%',
        'default' => true,
        'name' => 'tipo',
      ),
      'codigosap' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CODIGOSAP',
        'width' => '10%',
        'default' => true,
        'name' => 'codigosap',
      ),
      'description' => 
      array (
        'type' => 'text',
        'label' => 'LBL_DESCRIPTION',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'description',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'tipo' => 
      array (
        'type' => 'enum',
        'studio' => 'visible',
        'label' => 'LBL_TIPO',
        'width' => '10%',
        'default' => true,
        'name' => 'tipo',
      ),
      'codigosap' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CODIGOSAP',
        'width' => '10%',
        'default' => true,
        'name' => 'codigosap',
      ),
      'description' => 
      array (
        'type' => 'text',
        'label' => 'LBL_DESCRIPTION',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'description',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
;
?>
