<?php
$popupMeta = array (
    'moduleMain' => 'SCO_Cnf_Eventos_list',
    'varName' => 'SCO_Cnf_Eventos_list',
    'orderBy' => 'sco_cnf_eventos_list.name',
    'whereClauses' => array (
  'name' => 'sco_cnf_eventos_list.name',
  'tipo' => 'sco_cnf_eventos_list.tipo',
  'codigosap' => 'sco_cnf_eventos_list.codigosap',
  'description' => 'sco_cnf_eventos_list.description',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'tipo',
  5 => 'codigosap',
  6 => 'description',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
  'tipo' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_TIPO',
    'width' => '10%',
    'name' => 'tipo',
  ),
  'codigosap' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CODIGOSAP',
    'width' => '10%',
    'name' => 'codigosap',
  ),
  'description' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'name' => 'description',
  ),
),
);
