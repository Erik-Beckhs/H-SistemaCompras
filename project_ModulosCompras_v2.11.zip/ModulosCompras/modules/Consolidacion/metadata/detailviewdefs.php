<?php
$module_name = 'SCO_Consolidacion';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => true,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_DETAILVIEW_PANEL1' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'con_estado',
            'studio' => 'visible',
            'label' => 'LBL_CON_ESTADO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'con_descripcion',
            'label' => 'LBL_CON_DESCRIPCION',
          ),
          1 => '',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'con_cantitems',
            'label' => 'LBL_CON_CANTITEMS',
          ),
          1 => 
          array (
            'name' => 'sco_consolidacion_sco_proveedor_name',
            'label' => 'LBL_SCO_CONSOLIDACION_SCO_PROVEEDOR_FROM_SCO_PROVEEDOR_TITLE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'con_preciototal',
            'label' => 'LBL_CON_PRECIOTOTAL',
          ),
          1 => 
          array (
            'name' => 'sco_consolidacion_sco_ordencompra_name',
            'label' => 'LBL_SCO_CONSOLIDACION_SCO_ORDENCOMPRA_FROM_SCO_ORDENCOMPRA_TITLE',
          ),
        ),
      ),
      'lbl_detailview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
          1 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'modified_by_name',
            'label' => 'LBL_MODIFIED_NAME',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
      ),
    ),
  ),
);
;
?>
