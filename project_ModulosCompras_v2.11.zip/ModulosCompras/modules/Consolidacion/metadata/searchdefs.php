<?php
$module_name = 'SCO_Consolidacion';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'created_by' => 
      array (
        'type' => 'assigned_user_name',
        'label' => 'LBL_CREATED',
        'width' => '10%',
        'default' => true,
        'name' => 'created_by',
      ),
      'con_estado' => 
      array (
        'type' => 'dynamicenum',
        'studio' => 'visible',
        'label' => 'LBL_CON_ESTADO',
        'width' => '10%',
        'default' => true,
        'name' => 'con_estado',
      ),
      'sco_consolidacion_sco_ordencompra_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_SCO_CONSOLIDACION_SCO_ORDENCOMPRA_FROM_SCO_ORDENCOMPRA_TITLE',
        'id' => 'SCO_CONSOLIDACION_SCO_ORDENCOMPRASCO_ORDENCOMPRA_IDB',
        'width' => '10%',
        'default' => true,
        'name' => 'sco_consolidacion_sco_ordencompra_name',
      ),
      'sco_consolidacion_sco_proveedor_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_SCO_CONSOLIDACION_SCO_PROVEEDOR_FROM_SCO_PROVEEDOR_TITLE',
        'id' => 'SCO_CONSOLIDACION_SCO_PROVEEDORSCO_PROVEEDOR_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'sco_consolidacion_sco_proveedor_name',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
;
?>
