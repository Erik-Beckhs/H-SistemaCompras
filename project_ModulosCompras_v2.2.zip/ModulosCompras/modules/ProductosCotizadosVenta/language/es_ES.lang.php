<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2018 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Asignado a Usuario con Id',
  'LBL_ASSIGNED_TO_NAME' => 'Asignado a',
  'LBL_SECURITYGROUPS' => 'Grupos de Seguridad',
  'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => 'Grupos de Seguridad',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Fecha de Creación',
  'LBL_DATE_MODIFIED' => 'Última Modificación',
  'LBL_MODIFIED' => 'Modificado Por',
  'LBL_MODIFIED_NAME' => 'Modificado Por Nombre',
  'LBL_CREATED' => 'Creado por',
  'LBL_DESCRIPTION' => 'Descripción',
  'LBL_DELETED' => 'Borrado',
  'LBL_NAME' => 'Codigo AIO',
  'LBL_CREATED_USER' => 'Creado Por Usuario',
  'LBL_MODIFIED_USER' => 'Modificado por el usuario',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_REMOVE' => 'Quitar',
  'LBL_ASCENDING' => 'Ascendente',
  'LBL_DESCENDING' => 'Descendente',
  'LBL_OPT_IN' => 'Opt In',
  'LBL_OPT_IN_PENDING_EMAIL_NOT_SENT' => 'Autorización pendiente. Confirmación no enviada',
  'LBL_OPT_IN_PENDING_EMAIL_SENT' => 'Autorización pendiente. Confirmación ya enviada',
  'LBL_OPT_IN_CONFIRMED' => 'Adherido',
  'LBL_LIST_FORM_TITLE' => 'Productos Cotizados de Venta Lista',
  'LBL_MODULE_NAME' => 'Productos Cotizados de Venta',
  'LBL_MODULE_TITLE' => 'Productos Cotizados de Venta',
  'LBL_HOMEPAGE_TITLE' => 'Mi Productos Cotizados de Venta',
  'LNK_NEW_RECORD' => 'Crear Productos Cotizados de Venta',
  'LNK_LIST' => 'Vista Productos Cotizados de Venta',
  'LNK_IMPORT_SCO_PRODUCTOSCOTIZADOSVENTA' => 'Importar Productos Cotizados de Venta',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda Productos Cotizados de Venta',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Ver Historial',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_SCO_PRODUCTOSCOTIZADOSVENTA_SUBPANEL_TITLE' => 'Productos Cotizados de Venta',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Productos Cotizados de Venta',
  'LBL_PCV_IDCOTIZACION' => 'idCotizacion',
  'LBL_PCV_IDPRODUCTO' => 'idProducto',
  'LBL_PCV_NUMEROCOTIZACION' => 'Numero Cotización',
  'LBL_PCV_CODIGOAIO' => 'CódigoAIO',
  'LBL_PCV_DESCRIPCION' => 'Descripción',
  'LBL_PCV_AM' => 'Area mercado',
  'LBL_PCV_FAMILIA' => 'Familia',
  'LBL_PCV_VENDEDOR' => 'Vendedor',
  'LBL_PCV_PROVEEDORAIO' => 'ProveedorAIO',
  'LBL_PCV_NOMBREPROVEEDOR' => 'Nombre Proveedor',
  'LBL_PCV_CLIENTE' => 'Cliente',
  'LBL_PCV_CLIENTEAIO' => 'ClienteAIO',
  'LBL_PCV_CANTIDAD' => 'Cantidad',
  'LBL_PCV_COTIZACION' => 'Cotizado',
  'LBL_PCV_CANTIDADCONSOLIDADO' => 'Cantidad Consolidado',
  'LBL_PCV_PLZENTREGA' => 'Plazo de entrega',
  'LBL_PCV_ESTADO' => 'Estado',
  'LBL_EDITVIEW_PANEL1' => 'Nuevo Panel 1',
  'LBL_EDITVIEW_PANEL2' => 'Nuevo Panel 2',
  'LBL_EDITVIEW_PANEL3' => 'Nuevo Panel 3',
  'LBL_EDITVIEW_PANEL4' => 'Producto',
  'LBL_EDITVIEW_PANEL5' => 'Proveedor',
  'LBL_EDITVIEW_PANEL6' => 'Información',
  'LBL_PCV_PRECIOFOB' => 'Precio FOB',
  'LBL_IDDIVISION_C' => 'División',
  'LBL_IDAMERCADO_C' => 'Area mercado',
  'LBL_IDREGIONAL_C' => 'Regional',
  'LBL_IDGRUPOCLIENTE_C' => 'Grupo cliente',
  'LBL_PCV_CODIGOPROVEEDOR' => 'Codigo Proveedor',
  'LBL_PCV_FECHACRM' => 'Fecha envío crm ventas',
  'LBL_PCV_CANTIDADSALDO' => 'Cantidad saldos',
  'LBL_SCO_PRODUCTOSCOTIZADOSVENTA_SCO_PROVEEDOR_FROM_SCO_PROVEEDOR_TITLE' => 'Proveedor',
  'LBL_PCV_PROVEEDOR_SCO_PROVEEDOR_ID' => '\'Proveedor\' (relacionado \'\' ID)',
  'LBL_PCV_PROVEEDOR' => 'Proveedor',
);