<?php
$module_name = 'SCO_ProductosCotizadosVenta';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_EDITVIEW_PANEL6' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL4' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_editview_panel6' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'pcv_cotizacion',
            'label' => 'LBL_PCV_COTIZACION',
          ),
          1 => 
          array (
            'name' => 'pcv_numerocotizacion',
            'label' => 'LBL_PCV_NUMEROCOTIZACION',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'pcv_vendedor',
            'label' => 'LBL_PCV_VENDEDOR',
          ),
          1 => 
          array (
            'name' => 'pcv_plzentrega',
            'label' => 'LBL_PCV_PLZENTREGA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'pcv_cliente',
            'label' => 'LBL_PCV_CLIENTE',
          ),
          1 => 
          array (
            'name' => 'pcv_clienteaio',
            'label' => 'LBL_PCV_CLIENTEAIO',
          ),
        ),
      ),
      'lbl_editview_panel4' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'pcv_estado',
            'studio' => 'visible',
            'label' => 'LBL_PCV_ESTADO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'pcv_descripcion',
            'label' => 'LBL_PCV_DESCRIPCION',
          ),
          1 => 
          array (
            'name' => 'pcv_preciofob',
            'label' => 'LBL_PCV_PRECIOFOB',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'pcv_cantidad',
            'label' => 'LBL_PCV_CANTIDAD',
          ),
          1 => 
          array (
            'name' => 'pcv_cantidadconsolidado',
            'label' => 'LBL_PCV_CANTIDADCONSOLIDADO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'pcv_familia',
            'label' => 'LBL_PCV_FAMILIA',
          ),
          1 => 
          array (
            'name' => 'pcv_am',
            'studio' => 'visible',
            'label' => 'LBL_PCV_AM',
          ),
        ),
      ),
    ),
  ),
);
;
?>
