<?php
$module_name = 'SCO_Cnf_comentarios';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'CNF_COMENTARIOS' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_CNF_COMENTARIOS',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'CNF_DIVISION' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CNF_DIVISION',
    'width' => '10%',
    'default' => true,
  ),
  'CNF_REGIONAL' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CNF_REGIONAL',
    'width' => '10%',
    'default' => true,
  ),
);
?>
