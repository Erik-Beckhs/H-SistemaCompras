<?php
$module_name='SCO_ProductosCotizadosVenta';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SCO_ProductosCotizadosVenta',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'pcv_numerocotizacion' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PCV_NUMEROCOTIZACION',
      'width' => '10%',
      'default' => true,
    ),
    'pcv_codigoproveedor' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PCV_CODIGOPROVEEDOR',
      'width' => '10%',
      'default' => true,
    ),
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'pcv_descripcion' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PCV_DESCRIPCION',
      'width' => '10%',
      'default' => true,
    ),
    'pcv_am' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_PCV_AM',
      'width' => '10%',
      'default' => true,
    ),
    'pcv_vendedor' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PCV_VENDEDOR',
      'width' => '10%',
      'default' => true,
    ),
    'pcv_cliente' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PCV_CLIENTE',
      'width' => '10%',
      'default' => true,
    ),
    'pcv_cantidad' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_PCV_CANTIDAD',
      'width' => '10%',
      'default' => true,
    ),
    'pcv_preciofob' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_PCV_PRECIOFOB',
      'width' => '10%',
      'default' => true,
    ),
    'pcv_fechaconfirmacion' => 
    array (
      'type' => 'datetimecombo',
      'vname' => 'LBL_PCV_FECHACONFIRMACION',
      'width' => '10%',
      'default' => true,
    ),
    'pcv_cantidadconsolidado' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_PCV_CANTIDADCONSOLIDADO',
      'width' => '10%',
      'default' => true,
    ),
  ),
);