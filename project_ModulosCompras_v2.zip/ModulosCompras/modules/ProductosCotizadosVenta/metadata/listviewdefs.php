<?php
$module_name = 'SCO_ProductosCotizadosVenta';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PCV_NOMBREPROVEEDOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_NOMBREPROVEEDOR',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_PROVEEDORAIO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_PROVEEDORAIO',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_DESCRIPCION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_DESCRIPCION',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_AM' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_PCV_AM',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_FAMILIA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_FAMILIA',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_VENDEDOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_VENDEDOR',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_CLIENTE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_CLIENTE',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_COTIZACION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_COTIZACION',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_NUMEROCOTIZACION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_NUMEROCOTIZACION',
    'width' => '10%',
    'default' => false,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
;
?>
