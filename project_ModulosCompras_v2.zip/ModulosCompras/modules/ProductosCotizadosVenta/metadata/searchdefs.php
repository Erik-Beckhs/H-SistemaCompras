<?php
$module_name = 'SCO_ProductosCotizadosVenta';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'pcv_proveedoraio' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_PROVEEDORAIO',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_proveedoraio',
      ),
      'pcv_clienteaio' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_CLIENTEAIO',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_clienteaio',
      ),
      'pcv_numerocotizacion' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_NUMEROCOTIZACION',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_numerocotizacion',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'pcv_numerocotizacion' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_NUMEROCOTIZACION',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_numerocotizacion',
      ),
      'pcv_vendedor' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_VENDEDOR',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_vendedor',
      ),
      'pcv_proveedoraio' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_PROVEEDORAIO',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_proveedoraio',
      ),
      'pcv_nombreproveedor' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_NOMBREPROVEEDOR',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_nombreproveedor',
      ),
      'pcv_cliente' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_CLIENTE',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_cliente',
      ),
      'pcv_clienteaio' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_CLIENTEAIO',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_clienteaio',
      ),
      'pcv_estado' => 
      array (
        'type' => 'dynamicenum',
        'studio' => 'visible',
        'label' => 'LBL_PCV_ESTADO',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_estado',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
;
?>
