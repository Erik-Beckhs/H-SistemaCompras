<?php
$module_name = 'SCO_Aprobadores';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'apr_nombre',
            'label' => 'LBL_APR_NOMBRE',
          ),
          1 => 
          array (
            'name' => 'apr_tipo',
            'label' => 'LBL_APR_TIPO',
          ),
        ),
      ),
    ),
  ),
);
?>
