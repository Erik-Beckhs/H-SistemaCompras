<?php
$module_name = 'SCO_ProductosCotizadosVenta';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => true,
      'tabDefs' => 
      array (
        'LBL_EDITVIEW_PANEL6' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_DETAILVIEW_PANEL7' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL4' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL5' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_editview_panel6' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'pcv_numerocotizacion',
            'label' => 'LBL_PCV_NUMEROCOTIZACION',
          ),
          1 => '',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'pcv_vendedor',
            'label' => 'LBL_PCV_VENDEDOR',
          ),
          1 => '',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'pcv_cliente',
            'label' => 'LBL_PCV_CLIENTE',
          ),
          1 => 
          array (
            'name' => 'pcv_clienteaio',
            'label' => 'LBL_PCV_CLIENTEAIO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'sco_consolidacion_sco_productoscotizadosventa_name',
            'label' => 'LBL_SCO_CONSOLIDACION_SCO_PRODUCTOSCOTIZADOSVENTA_FROM_SCO_CONSOLIDACION_TITLE',
          ),
          1 => 
          array (
            'name' => 'pcv_consolidado',
            'label' => 'LBL_PCV_CONSOLIDADO',
          ),
        ),
      ),
      'lbl_detailview_panel7' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'comment' => 'Date record last modified',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        1 => 
        array (
          0 => '',
          1 => '',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'pcv_fechaconfirmacion',
            'label' => 'LBL_PCV_FECHACONFIRMACION',
          ),
          1 => '',
        ),
      ),
      'lbl_editview_panel4' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'pcv_estado',
            'studio' => 'visible',
            'label' => 'LBL_PCV_ESTADO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'pcv_descripcion',
            'label' => 'LBL_PCV_DESCRIPCION',
          ),
          1 => 
          array (
            'name' => 'pcv_preciofob',
            'label' => 'LBL_PCV_PRECIOFOB',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'pcv_cantidad',
            'label' => 'LBL_PCV_CANTIDAD',
          ),
          1 => 
          array (
            'name' => 'pcv_cantidadconsolidado',
            'label' => 'LBL_PCV_CANTIDADCONSOLIDADO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'pcv_familia',
            'label' => 'LBL_PCV_FAMILIA',
          ),
          1 => 
          array (
            'name' => 'pcv_am',
            'studio' => 'visible',
            'label' => 'LBL_PCV_AM',
          ),
        ),
      ),
      'lbl_editview_panel5' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'pcv_nombreproveedor',
            'label' => 'LBL_PCV_NOMBREPROVEEDOR',
          ),
          1 => 
          array (
            'name' => 'pcv_proveedoraio',
            'label' => 'LBL_PCV_PROVEEDORAIO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'pcv_codigoproveedor',
            'label' => 'LBL_PCV_CODIGOPROVEEDOR',
          ),
          1 => 
          array (
            'name' => 'pcv_proveedor',
            'studio' => 'visible',
            'label' => 'LBL_PCV_PROVEEDOR',
          ),
        ),
      ),
    ),
  ),
);
;
?>
