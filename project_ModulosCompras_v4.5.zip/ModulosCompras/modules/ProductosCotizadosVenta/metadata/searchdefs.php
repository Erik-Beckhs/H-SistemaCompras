<?php
$module_name = 'SCO_ProductosCotizadosVenta';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'pcv_numerocotizacion' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_NUMEROCOTIZACION',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_numerocotizacion',
      ),
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'pcv_proveedor' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PCV_PROVEEDOR',
        'id' => 'SCO_PROVEEDOR_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_proveedor',
      ),
      'pcv_clienteaio' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_CLIENTEAIO',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_clienteaio',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'pcv_numerocotizacion' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_NUMEROCOTIZACION',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_numerocotizacion',
      ),
      'pcv_vendedor' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_VENDEDOR',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_vendedor',
      ),
      'pcv_proveedoraio' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_PROVEEDORAIO',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_proveedoraio',
      ),
      'pcv_nombreproveedor' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_NOMBREPROVEEDOR',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_nombreproveedor',
      ),
      'pcv_cliente' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_CLIENTE',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_cliente',
      ),
      'pcv_clienteaio' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_PCV_CLIENTEAIO',
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_clienteaio',
      ),
      'pcv_proveedor' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_PCV_PROVEEDOR',
        'id' => 'SCO_PROVEEDOR_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'pcv_proveedor',
      ),
      'pcv_consolidado' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_PCV_CONSOLIDADO',
        'width' => '10%',
        'name' => 'pcv_consolidado',
      ),
      'sco_consolidacion_sco_productoscotizadosventa_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_SCO_CONSOLIDACION_SCO_PRODUCTOSCOTIZADOSVENTA_FROM_SCO_CONSOLIDACION_TITLE',
        'id' => 'SCO_CONSOLF10BIDACION_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'sco_consolidacion_sco_productoscotizadosventa_name',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
;
?>
