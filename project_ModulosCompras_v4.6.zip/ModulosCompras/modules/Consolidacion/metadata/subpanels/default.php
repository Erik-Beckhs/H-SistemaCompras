<?php
$module_name='SCO_Consolidacion';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SCO_Consolidacion',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'con_descripcion' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_CON_DESCRIPCION',
      'width' => '10%',
      'default' => true,
    ),
    'con_estado' => 
    array (
      'type' => 'dynamicenum',
      'studio' => 'visible',
      'vname' => 'LBL_CON_ESTADO',
      'width' => '10%',
      'default' => true,
    ),
    'con_cantitems' => 
    array (
      'type' => 'int',
      'vname' => 'LBL_CON_CANTITEMS',
      'width' => '10%',
      'default' => true,
    ),
    'con_preciototal' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_CON_PRECIOTOTAL',
      'width' => '10%',
      'default' => true,
    ),
    'iddivision_c' => 
    array (
      'type' => 'dynamicenum',
      'studio' => 'visible',
      'vname' => 'LBL_IDDIVISION_C',
      'width' => '10%',
      'default' => true,
    ),
  ),
);