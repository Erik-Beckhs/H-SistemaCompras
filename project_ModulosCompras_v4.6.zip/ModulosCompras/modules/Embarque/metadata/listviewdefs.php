<?php
$module_name = 'SCO_Embarque';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'EMB_ORIG' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMB_ORIG',
    'width' => '10%',
    'default' => true,
  ),
  'EMB_MODTRA' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_EMB_MODTRA',
    'width' => '10%',
    'default' => true,
  ),
  'EMB_DIASTRAN' => 
  array (
    'type' => 'int',
    'label' => 'LBL_EMB_DIASTRAN',
    'width' => '10%',
    'default' => true,
  ),
  'EMB_CANTCONT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMB_CANTCONT',
    'width' => '10%',
    'default' => true,
  ),
  'EMB_ESTADO' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_EMB_ESTADO',
    'width' => '10%',
    'default' => true,
  ),
  'EMB_PORESPACIO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMB_PORESPACIO',
    'width' => '10%',
    'default' => true,
  ),
  'EMB_PESO' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_EMB_PESO',
    'width' => '10%',
    'default' => true,
  ),
  'EMB_VOLUMEN' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_EMB_VOLUMEN',
    'width' => '10%',
    'default' => true,
  ),
  'EMB_RESUMEN' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_EMB_RESUMEN',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'EMB_TRANSP' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMB_TRANSP',
    'width' => '10%',
    'default' => false,
  ),
  'CREATED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CREATED',
    'id' => 'CREATED_BY',
    'width' => '10%',
    'default' => false,
  ),
  'REPORTE' => 
  array (
    'type' => 'url',
    'default' => false,
    'label' => 'LBL_REPORTE',
    'width' => '10%',
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
;
?>
