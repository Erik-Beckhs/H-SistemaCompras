<?php
$module_name='SCO_Productos';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SCO_Productos',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'items' => 
    array (
      'vname' => 'Items',
      'widget_class' => 'SubPanelProductosList',
      'width' => '30%',
      'default' => true,
    ),
  ),
);