<?php
$module_name = 'SCO_ProductosCotizadosVenta';
$listViewDefs [$module_name] = 
array (
  'PCV_NUMEROCOTIZACION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_NUMEROCOTIZACION',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PCV_DESCRIPCION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_DESCRIPCION',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_PROVEEDOR' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PCV_PROVEEDOR',
    'id' => 'SCO_PROVEEDOR_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'PCV_AM' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_PCV_AM',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_FAMILIA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_FAMILIA',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_VENDEDOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_VENDEDOR',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_CLIENTE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_CLIENTE',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_CANTIDAD' => 
  array (
    'type' => 'int',
    'label' => 'LBL_PCV_CANTIDAD',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_PRECIOFOB' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_PCV_PRECIOFOB',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_FECHACONFIRMACION' => 
  array (
    'type' => 'datetimecombo',
    'label' => 'LBL_PCV_FECHACONFIRMACION',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_CANTIDADCONSOLIDADO' => 
  array (
    'type' => 'int',
    'label' => 'LBL_PCV_CANTIDADCONSOLIDADO',
    'width' => '10%',
    'default' => true,
  ),
  'SCO_CONSOLIDACION_SCO_PRODUCTOSCOTIZADOSVENTA_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_SCO_CONSOLIDACION_SCO_PRODUCTOSCOTIZADOSVENTA_FROM_SCO_CONSOLIDACION_TITLE',
    'id' => 'SCO_CONSOLF10BIDACION_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'PCV_CODIGOPROVEEDOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_CODIGOPROVEEDOR',
    'width' => '10%',
    'default' => false,
  ),
  'PCV_PROVEEDORAIO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_PROVEEDORAIO',
    'width' => '10%',
    'default' => false,
  ),
  'PCV_NOMBREPROVEEDOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_NOMBREPROVEEDOR',
    'width' => '10%',
    'default' => false,
  ),
  'IDGRUPOCLIENTE_C' => 
  array (
    'type' => 'dynamicenum',
    'studio' => 'visible',
    'label' => 'LBL_IDGRUPOCLIENTE_C',
    'width' => '10%',
    'default' => false,
  ),
  'PCV_ESTADO' => 
  array (
    'type' => 'dynamicenum',
    'studio' => 'visible',
    'label' => 'LBL_PCV_ESTADO',
    'width' => '10%',
    'default' => false,
  ),
  'PCV_CLIENTEAIO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PCV_CLIENTEAIO',
    'width' => '10%',
    'default' => false,
  ),
  'PCV_PRODUCTOSCOMPRAS' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PCV_PRODUCTOSCOMPRAS',
    'id' => 'SCO_PRODUCTOSCOMPRAS_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => false,
  ),
);
;
?>
